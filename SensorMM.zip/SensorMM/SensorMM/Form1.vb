﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        rs232Port.PortName = ComboBox1.Text
        Try
            rs232Port.Open()

            Label1.Text = "Conexão Ativa"
        Catch ex As Exception
            MsgBox("Porta não está aberta")
            If rs232Port.IsOpen = False Then
                MsgBox("Portá não está aberta")
            End If
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try
            Timer1.Enabled = True

        Catch ex As Exception
            MsgBox("Com Errada")
            Label1.Text = "Sem Conexão"

        End Try
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Try
            TextBox1.Text = rs232Port.ReadExisting
            Dim SensorMM As String
            SensorMM = (TextBox1.Lines(0).ToString)



            Label2.Text = SensorMM




        Catch ex As Exception


        End Try
    End Sub
End Class
